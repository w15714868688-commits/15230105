# 许可与版权

## 文字与原创图表

本页面的文字、版式与以下原创图表由作者创作，采用 **Creative Commons Attribution 4.0 International（CC BY 4.0）** 许可：

- `assets/img/system-boundary.svg` — 系统安全边界
- `assets/img/risk-matrix.svg` — 危险源风险矩阵
- `assets/img/stpa.svg` — STPA 控制结构
- `assets/img/fta.svg` — LOC-I 故障树
- `assets/img/bowtie.svg` — 电池热失控 Bow-tie
- `assets/img/gsn.svg` — 安全案例 GSN
- `assets/img/layers.svg` — 纵深防御 / 瑞士奶酪

你可以复制、分发、修改这些内容，但需注明作者与来源（本课程作业），并附上许可链接：

<https://creativecommons.org/licenses/by/4.0/>

## 第三方图片

以下图片来自 ARIDGE 官方产品页（<https://www.aridge.com/>），版权归原权利人所有：

- `assets/img/hero-wide.webp`
- `assets/img/separation.webp`
- `assets/img/redundancy.webp`

上述图片仅用于课程研究与评论，**不在 CC BY 4.0 授权范围内**，不构成商业使用或官方背书。如权利人要求删除，请联系作者替换。

## 免责声明

本页面为课程作业，不是适航结论、事故调查报告、投资建议、法律意见或产品购买建议。页面中的风险矩阵、FTA、Bow-tie、STPA 场景与评分均为研究性分析，存在假设与误差；请以监管机构、标准、企业公告与原始事故调查为准。

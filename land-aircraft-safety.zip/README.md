# 安全，不是一个数字游戏

**小鹏汇天「陆地航母」/ X3-F 的系统安全分析**

《飞行汽车技术基础》课程作业-2 · 2026

---

## 这是什么

一个不依赖任何框架、构建工具或外部 CDN 的单页研究网站。入口文件是根目录的 `index.html`，直接用浏览器打开即可阅读。

这是课程作业-2，研究对象与作业-1 相同：小鹏汇天「陆地航母」量产构型（陆行体 + 飞行体 X3-F）。作业-1 回答“能不能飞、卖给谁”；本页面只回答安全问题：

1. **它会在哪里出事？** 用 PHA / 危险清单 / 风险矩阵，识别 12 个危险源。
2. **失效如何发生？** 用 FHA / FTA / FMEA / Bow-tie，分析升力、姿态、能量、折叠、撤离与电池火灾。
3. **谁给出了不安全的控制动作？** 用 STPA，分析监管、运营人、飞行员、飞控、维修、地面保障与空域。
4. **它凭什么被说成“安全”？** 用适航基础、安全目标、SMS / SPI 与 GSN 安全案例，区分“设计意图”和“可审查证据”。

核心判断：**它可能是安全的，但安全还没有被公开证明。** 冗余不是安全；冗余只是把单点失效，变成“需要被正确管理的多点失效”。

---

## 页面结构

- **00 摘要**：设计 / 取证 / 运行三个维度的结论，五个最危险的时刻。
- **01 研究设计**：对象、边界、方法（PHA/FHA/STPA/FTA/FMEA/SOTIF/ARP4754A/ISO）、证据分级。
- **02 系统与边界**：八个安全关键功能、四类边界、LSA 特殊条件。
- **03 危险与风险**：12 个危险源、风险矩阵、第三方风险的非对称性。
- **04 失效分析**：FHA、LOC-I 故障树、FMEA、电池 Bow-tie、“坏两个还能飞”的六个限定。
- **05 STPA 与案例**：控制结构、8 个 UCA、6 个损失场景、2025 长春航展事件分析。
- **06 适航与安全目标**：传统 LSA 的 700 kg / 单发错位、EASA SC-VTOL 安全目标、四证与 GSN、机队期望事件计算器。
- **07 运行与应急**：运行包线、地面运行、应急响应、维修、人因、网络安全、SMS/SPI。
- **08 安全改进**：按设计/取证/运行/维修/组织分层的建议、6 个 Go/No-Go 门槛、路线图。
- **09 结论与局限**：评分、三个判断、未回答问题。
- **参考文献与附录**：37 条来源、关键安全说法审计、假设、AI 使用、图片版权。

页面包含 17 张表、9 幅图（系统边界、风险矩阵、FTA、Bow-tie、STPA、GSN、纵深防御等原创 SVG），以及可交互的机队期望事件计算器。

---

## 本地预览

无需安装依赖：

```bash
# 方式一：直接双击 index.html
# 方式二：起一个本地静态服务器（推荐）
python -m http.server 8000
# 访问 http://localhost:8000
```

推荐最新版 Chrome / Edge / Safari / Firefox。页面为响应式设计，桌面与移动端均可阅读。

---

## 文件结构

```text
.
├─ index.html
├─ assets/
│  ├─ css/style.css
│  ├─ js/app.js
│  └─ img/
│     ├─ hero-wide.webp / separation.webp / redundancy.webp
│     ├─ system-boundary.svg
│     ├─ risk-matrix.svg
│     ├─ stpa.svg
│     ├─ fta.svg
│     ├─ bowtie.svg
│     ├─ gsn.svg
│     ├─ layers.svg
│     ├─ favicon.svg
│     └─ og-safety.jpg
├─ docs/
│  └─ ai-usage.md
├─ README.md
└─ LICENSE.md
```

---

## 提交到 GitHub（课程要求）

课程要求：**Public 仓库 + 根目录 `index.html` + 把网页链接填入“作业收集”表**。

### 1. 创建仓库

在 GitHub 新建 **Public** 仓库，建议名 `land-aircraft-safety`。不要勾选 “Add a README file”。

### 2. 上传本目录

```bash
cd land-aircraft-safety
git init
git add .
git commit -m "Course assignment 2: AeroHT Land Aircraft Carrier safety analysis"
git branch -M main
git remote add origin https://github.com/<你的用户名>/land-aircraft-safety.git
git push -u origin main
```

> 也可以在 GitHub 网页端 “Add file → Upload files” 拖入本目录全部内容。务必确认 **`index.html` 在仓库根目录**。

### 3. 开启 GitHub Pages

仓库页 → **Settings** → **Pages** → **Build and deployment**：

- Source: **Deploy from a branch**
- Branch: **main** / **/(root)**
- Save

等待 1–3 分钟，访问：

```text
https://<你的用户名>.github.io/land-aircraft-safety/
```

### 4. 提交链接

把网页链接填入课程幻灯片右侧二维码对应的“飞行汽车技术基础-作业收集”表。作业-2 截止时间：**2026-11-26 18:00**。

> 如果 GitHub Pages 在当前网络下访问不稳定，可以保留 Public 仓库，同时用 Netlify / Vercel / Cloudflare Pages 部署同一目录，提交可访问的镜像链接；但不要只交本地文件。

---

## 证据与边界

- **证据截止**：2026-11-24。
- **证据分级**：A 监管/标准/官方文件；B 主流媒体/公告；C 企业营销材料；D 本报告推断/待验证。
- **关键校正**：
  - 传统 LSA 定义是 **≤700 kg、2 座、单台发动机**；X3-F 是 **880 kg、6 台电机、6 副旋翼**，因此需要专用条件，不能直接套用 LSA 安全记录。
  - 截至 2026-11-24，**TC 待颁、PC 审查中、AC 未发**；专用条件仍是 2025-03 征求意见稿。
  - “六副旋翼坏两副仍可安全飞行”是企业口径，缺少公开的试验条件、剩余操纵裕度与“安全”的定义。
  - 2025-09-16 长春航展两机接触/起火，企业称现场人员安全；截至证据截止日，未见公开最终调查结论。
  - 风险矩阵、FTA、Bow-tie、GSN 均为定性/示意分析，不是定量概率模型。

完整来源见第 09 章；关键安全说法审计见附录 A。

---

## AI 使用记录

详见 [`docs/ai-usage.md`](docs/ai-usage.md)。简要说明：

- AI 用于资料检索辅助、结构梳理、文字草拟、图表设计、计算、前端实现与排版检查。
- 所有事实均要求回溯至公开来源；AI 未用于生成不存在的引用。
- 分析、评分与判断由作者负责；读者应优先核对原始来源。

---

## 图片版权

- 产品照片来自 **ARIDGE 官方产品页**（<https://www.aridge.com/>），版权归原权利人所有，仅用于课程研究与评论，不构成商业使用或官方背书。
- 系统边界图、风险矩阵、STPA、FTA、Bow-tie、GSN、纵深防御图为本文原创 SVG，采用 **CC BY 4.0** 许可（署名：本课程作业）。
- 如权利人要求删除某张图片，请联系作者替换。

---

## 许可

- 文字与原创图表：**CC BY 4.0**（见 `LICENSE.md`）。
- 第三方产品图片：版权归原权利人，不在 CC BY 4.0 授权范围内。

---

## 作者信息

提交前可在此补充：

- 姓名：`________`
- 学号：`________`
- 课程：飞行汽车技术基础
- 学期：2026 秋
